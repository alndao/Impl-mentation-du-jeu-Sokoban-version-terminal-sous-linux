#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

char ** creTab(int n, int m);

int ** creTab2(int n, int m);

void affiche_Map(char ** map, int longu, int larg);

void recupe_Dim_Map(int * longu, int * larg, char * fichier);

char ** charge_Map(char * fichier);

int NbrePointsInteret(int longueur, int largeur,  char ** Map);

int ** stock_Pos_Points_Interet(int longueur, int largeur, char ** Map);

void Position_du_Perso(int *pos_x, int *pos_y, char ** Map, int longueur, int largeur);

int verif_Si_Points_Intert(int pos_x, int pos_y, int ligne, int ** tab);

void Deplacer_Perso(int pos_x, int pos_y, int longueur, int largeur, char ** Map, char decalage, int ** caisses_dest, int nbre);

int nbr_Caisse_Bien_Place(int longueur, int largeur, char ** Map);

char ** niveau_Suivant(int n, int * largueur, int * largeur);
