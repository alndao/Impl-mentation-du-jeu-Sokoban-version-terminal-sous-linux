#include"fonction.h"

int main()
{
	
	char choix;
	
	int rep;

	printf("Donner le numéro du niveau que vous souhaitez jouer \nparmi les 60 : \n");
				
	scanf("%d", &rep);

	int * LARGEUR_MAP = malloc(sizeof(int));
	
	int * LONGUEUR_MAP = malloc(sizeof(int));

	char ** map = niveau_Suivant(rep, LONGUEUR_MAP, LARGEUR_MAP); // on recupere le map et ses dimensions

	int ** caisses_dest = stock_Pos_Points_Interet(*LONGUEUR_MAP, *LARGEUR_MAP, map);

	int nbre = NbrePointsInteret(*LONGUEUR_MAP, *LARGEUR_MAP, map); // nombre de points d'interets

	int * pos_x = malloc(sizeof(int));
	int * pos_y = malloc(sizeof(int));

        system("clear");

	affiche_Map(map, *LONGUEUR_MAP, *LARGEUR_MAP); // afficher le map

	time_t start = time(NULL); // on déclenche le chrono
	
	int N = 0; // N sera le nombre de déplacement du perso
	int pos_x_tmp = -1; 
	int pos_y_tmp = -1;

	while (choix != 'q')
	{
		Position_du_Perso(pos_x, pos_y, map, *LONGUEUR_MAP, *LARGEUR_MAP); // on recupere la position du perso
		
		// Pour connaitre le nombre de déplacement du perso
		if (pos_x_tmp != *pos_x && pos_y_tmp != *pos_y)
		{
			N++;
			pos_x_tmp = *pos_x;
			pos_y_tmp = *pos_y;
		}

		choix = getchar(); // on recupere les saisis de l'utilisateur
		
		switch (choix)
		{	
			case 'h':
		
			      Deplacer_Perso(*pos_x, *pos_y, *LONGUEUR_MAP, *LARGEUR_MAP, map, 'h', caisses_dest, nbre);
				break;
		
			case 'b':
				Deplacer_Perso(*pos_x, *pos_y, *LONGUEUR_MAP, *LARGEUR_MAP, map, 'b', caisses_dest, nbre);
				break;
		
			case 'd':
				Deplacer_Perso(*pos_x, *pos_y, *LONGUEUR_MAP, *LARGEUR_MAP, map, 'd', caisses_dest, nbre);
				break;
		
			case 'g':
				Deplacer_Perso(*pos_x, *pos_y, *LONGUEUR_MAP, *LARGEUR_MAP, map, 'g', caisses_dest, nbre);
				break;
		}
		
		system("clear");

		affiche_Map(map, *LONGUEUR_MAP, *LARGEUR_MAP);

		if (nbre == nbr_Caisse_Bien_Place(*LONGUEUR_MAP, *LARGEUR_MAP, map) || choix == 'q' )
		{
			int D = (int) (time (NULL) - start);
			int score = (900000 * nbr_Caisse_Bien_Place(*LONGUEUR_MAP, *LARGEUR_MAP, map)) / ( D * N);	
			
			if (nbre == nbr_Caisse_Bien_Place(*LONGUEUR_MAP, *LARGEUR_MAP, map)) 
			{
				printf("Vous avez gagné la partie !\n");				
				printf("Durée = %ds\n", (int) (time (NULL) - start));
				printf("Score = %d\n", score * 10); // si la partie est finie on divise le temps mis par 10
			
			}

			else if (choix == 'q')
			{
				printf("Vous n'avez pas fini la partie !\n");				
				printf("Durée = %ds\n", (int) (time (NULL) - start));
				printf("Score = %d\n", score);
				
			}

			choix = 'q';

		}
	}

}
