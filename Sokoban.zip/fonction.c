#include"fonction.h"

// Cette fonction permet de créer un tableau de caractere 2D par une allocation dynamique

char ** creTab(int n, int m)
{
	char ** tab = NULL;
	tab = malloc(sizeof(char *) * n);
	if (tab == NULL)
	{
		perror("Probleme d'allocation");
		return NULL; 
	}
	int i;
	for (i = 0; i < n; i++)
	{
		tab[i] = malloc(sizeof(char) * m);
		if (tab[i] == NULL)
		{
			int k;
			for (k = 0; k < n; k++)
			{
				free(tab[k]);
			}
			free(tab);
			return NULL;
		}
	}
	return tab;
}

// Cette fonction permet de créer un tableau d'entier 2D par une allocation dynamique

int ** creTab2(int n, int m)
{
	int ** tab = NULL;
	tab = malloc(sizeof(int *) * n);
	if (tab == NULL)
	{
		perror("Probleme d'allocation");
		return NULL; 
	}
	int i;
	for (i = 0; i < n; i++)
	{
		tab[i] = malloc(sizeof(int) * m);
		if (tab[i] == NULL)
		{
			int k;
			for (k = 0; k < n; k++)
			{
				free(tab[k]);
			}
			free(tab);
			return NULL;
		}
	}
	return tab;
}


// afficher le map

void affiche_Map(char ** map, int longu, int larg)
{
	for (int i = 0; i < longu; i++)
	{
		for (int j = 0; j < larg; j++)
		{
			printf("%c",map[i][j]);
		}
		printf("\n");
	}
}

// recuperer la longueur et la largeur du map

void recupe_Dim_Map(int * longu, int * larg, char * fichier) 
{
	FILE * f = fopen(fichier, "r");
	
	fscanf(f, "%d", larg);

	fscanf(f, "%d", longu);

	rewind(f);

	fclose(f);
}

// charger le Map depuis un fichier txt

char ** charge_Map(char * fichier)
{

	FILE * f = fopen(fichier, "r");

	int longu;
	int larg;
        fscanf(f, "%d", &larg); // largeur
	fscanf(f, "%d", &longu); // longueur
	
	fseek(f, 1, SEEK_CUR); // On avance le curseur d'un cran 

	int k;

	char ** map = NULL;
	
	map = creTab(longu, larg);
	
	for (int i = 0; i < longu; i++)
	{
		char * tmp = NULL;
		tmp = malloc(sizeof(char) * larg);
		
		k = fgetc(f);

		int j = 0;

		while (k != '\n')
		{
			tmp[j] = k;
			k = fgetc(f);	
			j++;
		}
		map[i] = tmp;
	}

	fclose(f);
	
	return map;
} 


// le tableau tab sert à stocker les indexes des cases des points interets.


// Cette fonction permet de compter le nombre de points d'interets

int NbrePointsInteret(int longueur, int largeur,  char ** Map)
{
	int compteur = 0;

	for (int i = 0; i < longueur; i++)
	{
		for (int j = 0; j < largeur; j++)
		{
			if (Map[i][j] == 'I')
				
				compteur += 1;
		}
	
	}
	return compteur; 
}

//Cette fonction permet de stocker les positions des points d'interets dans unn tableau

int ** stock_Pos_Points_Interet(int longueur, int largeur, char ** Map)
{
	int m = 0;

	int nbr_points_inter = NbrePointsInteret(longueur, largeur, Map);

	int ** tab = creTab2(2, nbr_points_inter);

	for (int i = 0; i < longueur; i++)
	{
		for (int j = 0; j < largeur; j++)
		{
			if (Map[i][j] == 'I')
			{	
				tab[0][m] = i;
				tab[1][m] = j;
				m++;
			}
		}
	}
	return tab;
}	


//cette fonction permet de detereminer la position du personnage

void Position_du_Perso(int *pos_x, int *pos_y, char ** Map, int longueur, int largeur)
{

	for (int i = 0; i < longueur; i++)
	{
		for (int j = 0; j < largeur; j++)
		{

			if (Map[i][j] == 'P')
			{
				*pos_x = i;
				*pos_y = j;
			}
		}
	}
}


//Cette fonction permet de verifier si le personnage est dans un pointsa d'interets
//elle retourne vrai si c'est le cas faux sinon


int verif_Si_Points_Intert(int pos_x, int pos_y, int ligne, int ** tab)
{
	for (int i = 0; i < ligne; i++)
	{
		if (tab[0][i] == pos_x && tab[1][i] == pos_y)

			return 1;
	}
	return 0;		
}

// Cette fonction permet de deplacer le personnage

void Deplacer_Perso(int pos_x, int pos_y, int longueur, int largeur, char ** Map, char decalage, int ** caisses_dest, int nbre)
{

	if ( decalage == 'h')
	{
		if (Map[pos_x - 1][pos_y] != '#')
		{
			
			if (Map[pos_x - 1][pos_y] == ' ')
			{
				Map[pos_x - 1][pos_y] = 'P';
				
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
					Map[pos_x][pos_y] = 'I';
				else

					Map[pos_x][pos_y] = ' ';
				
			}

			else if (Map[pos_x - 1][pos_y] == 'C')
			{
				if (Map[pos_x - 2][pos_y] != '#' && Map[pos_x - 2][pos_y] != 'C')
				{
					
					if (Map[pos_x - 2][pos_y] == 'I')
					{
						Map[pos_x - 2][pos_y] = 'o';
						Map[pos_x - 1][pos_y] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
							Map[pos_x][pos_y] = 'I';
						else

							Map[pos_x][pos_y] = ' ';
						
					}

					else if (Map[pos_x - 2][pos_y] == ' ')
					{
						Map[pos_x - 2][pos_y] = 'C';

						Map[pos_x - 1][pos_y] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
						{
							Map[pos_x][pos_y] = 'I';
						}
						else
						{
							Map[pos_x][pos_y] = ' ';
						}
					}
				}	

			}
			else if (Map[pos_x - 1][pos_y] == 'I')
			{
				Map[pos_x - 1][pos_y] = 'P';
			
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
					Map[pos_x][pos_y] = 'I';
			
				else
			
					Map[pos_x][pos_y] = ' ';
			
			}
			else if (Map[pos_x - 1][pos_y] == 'o')
			{
				if (Map[pos_x - 2][pos_y] != '#' && Map[pos_x - 2][pos_y] != 'C' && Map[pos_x - 2][pos_y] != 'o')
				{
					if (verif_Si_Points_Intert(pos_x - 2, pos_y, nbre, caisses_dest) == 1)

						Map[pos_x - 2][pos_y] = 'o';

					else

						Map[pos_x - 2][pos_y] = 'C';
					
					Map[pos_x - 1][pos_y] = 'P';
					
					if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
						Map[pos_x][pos_y] = 'I';
			
					else
			
						Map[pos_x][pos_y] = ' ';
		
				}
			}	
		}
	}

	// Pour se deplacer vers le bas
	
	else if (decalage == 'b')
	{
		if (Map[pos_x +1][pos_y] != '#')
		{
			
			if (Map[pos_x + 1][pos_y] == ' ')
			{
				Map[pos_x + 1][pos_y] = 'P';
				
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
					Map[pos_x][pos_y] = 'I';
				else

					Map[pos_x][pos_y] = ' ';

			}

			else if (Map[pos_x + 1][pos_y] == 'C')
			{
				if (Map[pos_x + 2][pos_y] != '#' && Map[pos_x + 2][pos_y] != 'C')
				{
					
					if (Map[pos_x + 2][pos_y] == 'I')
					{
						Map[pos_x + 2][pos_y] = 'o';
						Map[pos_x + 1][pos_y] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
							Map[pos_x][pos_y] = 'I';
						else

							Map[pos_x][pos_y] = ' ';

					}

					else if (Map[pos_x + 2][pos_y] == ' ')
					{
						Map[pos_x + 2][pos_y] = 'C';

						Map[pos_x + 1][pos_y] = 'P';
					
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
							Map[pos_x][pos_y] = 'I';
						else

							Map[pos_x][pos_y] = ' ';

					}
				}	

			}
			else if (Map[pos_x + 1][pos_y] == 'I')
			{
				Map[pos_x + 1][pos_y] = 'P';
			
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
					Map[pos_x][pos_y] = 'I';
			
				else
			
					Map[pos_x][pos_y] = ' ';

			}
			else if (Map[pos_x + 1][pos_y] == 'o')
			{
				if (Map[pos_x + 2][pos_y] != '#' && Map[pos_x + 2][pos_y] != 'C' && Map[pos_x + 2][pos_y] != 'o')
				{
					if (verif_Si_Points_Intert(pos_x + 2, pos_y, nbre, caisses_dest) == 1)

						Map[pos_x + 2][pos_y] = 'o';

					else

						Map[pos_x + 2][pos_y] = 'C';
					
					Map[pos_x + 1][pos_y] = 'P';					
					
					if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					
						Map[pos_x][pos_y] = 'I';
			
					else
			
						Map[pos_x][pos_y] = ' ';
				}
			}
			 
		}
	}

	// deplacer le personnage vers la droite
	
	if ( decalage == 'd')
	{

		if (Map[pos_x][pos_y + 1] != '#')
		{
			
			if (Map[pos_x][pos_y + 1] == ' ')
			{
			
				Map[pos_x][pos_y + 1] = 'P';
					
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
				{	
					Map[pos_x][pos_y] = 'I';
				}
				else
				{
					Map[pos_x][pos_y] = ' ';
				}
				
			}

			else if (Map[pos_x][pos_y + 1] == 'C')
			{
				if (Map[pos_x][pos_y + 2] != '#' && Map[pos_x][pos_y + 2] != 'C')
				{
					
					if (Map[pos_x][pos_y + 2] == 'I')
					{
						printf("On y est\n");

						Map[pos_x][pos_y + 2] = 'o';
						Map[pos_x][pos_y + 1] = 'P';

						printf("On y est\n");
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
						{	
							Map[pos_x][pos_y] = 'I';
						}
						else
						{
							Map[pos_x][pos_y] = ' ';
						}
						
					}

					else if (Map[pos_x][pos_y + 2] == ' ')
					{
						Map[pos_x][pos_y + 2] = 'C';

						Map[pos_x][pos_y + 1] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
						{	
							Map[pos_x][pos_y] = 'I';
						}
						else
						{
							Map[pos_x][pos_y] = ' ';
						}
						
					}
				}
			
			}
			else if (Map[pos_x][pos_y + 1] == 'I')
			{
				Map[pos_x][pos_y + 1] = 'P';
				
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
				{
					Map[pos_x][pos_y] = 'I';
				}
				else
				{
					Map[pos_x][pos_y] = ' ';
				}
			}

			else if (Map[pos_x][pos_y + 1] == 'o')
			{
				if (Map[pos_x][pos_y + 2] != '#' && Map[pos_x][pos_y + 2] != 'C' && Map[pos_x][pos_y + 2] != 'o')
				{
					
					if (verif_Si_Points_Intert(pos_x, pos_y + 2, nbre, caisses_dest) == 1)
					{
						Map[pos_x][pos_y + 2] = 'o';
					}
					else
					{
						Map[pos_x][pos_y + 2] = 'C';
					}
				
					Map[pos_x][pos_y + 1] = 'P';

					if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					{
						Map[pos_x][pos_y] = 'I';
					}
					else
					{
						Map[pos_x][pos_y] = ' ';
					}

	
				}
			}	
			
		}
	}
	
	// deplacer vers la gauche
	
	if ( decalage == 'g')
	{

		if (Map[pos_x][pos_y - 1] != '#')
		{
			
			if (Map[pos_x][pos_y - 1] == ' ')
			{
			
				Map[pos_x][pos_y - 1] = 'P';
					
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
				{	
					Map[pos_x][pos_y] = 'I';
				}
				else
				{
					Map[pos_x][pos_y] = ' ';
				}
				
			}

			else if (Map[pos_x][pos_y - 1] == 'C')
			{
				if (Map[pos_x][pos_y - 2] != '#' && Map[pos_x][pos_y - 2] != 'C')
				{
					
					if (Map[pos_x][pos_y - 2] == 'I')
					{
						Map[pos_x][pos_y - 2] = 'o';
						Map[pos_x][pos_y - 1] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
						{	
							Map[pos_x][pos_y] = 'I';
						}
						else
						{
							Map[pos_x][pos_y] = ' ';
						}
						
					}

					else if (Map[pos_x][pos_y - 2] == ' ')
					{
						Map[pos_x][pos_y - 2] = 'C';

						Map[pos_x][pos_y - 1] = 'P';
						
						if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
						{	
							Map[pos_x][pos_y] = 'I';
						}
						else
						{
							Map[pos_x][pos_y] = ' ';
						}
						
					}
				}
			
			}
			else if (Map[pos_x][pos_y - 1] == 'I')
			{
				Map[pos_x][pos_y - 1] = 'P';
				
				if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
				{
					Map[pos_x][pos_y] = 'I';
				}
				else
				{
					Map[pos_x][pos_y] = ' ';
				}
			}

			else if (Map[pos_x][pos_y - 1] == 'o')
			{
				if (Map[pos_x][pos_y - 2] != '#' && Map[pos_x][pos_y - 2] != 'C' && Map[pos_x][pos_y - 2] != 'o')
				{
					
					if (verif_Si_Points_Intert(pos_x, pos_y - 2, nbre, caisses_dest) == 1)
					{
						Map[pos_x][pos_y - 2] = 'o';
					}
					else
					{
						Map[pos_x][pos_y - 2] = 'C';
					}
					
					Map[pos_x][pos_y - 1] = 'P';

					if (verif_Si_Points_Intert(pos_x, pos_y, nbre, caisses_dest) == 1)
					{
						Map[pos_x][pos_y] = 'I';
					}
					else
					{
						Map[pos_x][pos_y] = ' ';
					}

	
				}
			}	
			
		}
	}
	
}

// Cette fonction compte le nombre de caisses placer dans le bon endroit

int nbr_Caisse_Bien_Place(int longueur, int largeur, char ** Map)
{
	int i;
	int j;
	int compteur = 0;
	for (i = 0; i < longueur; i++)
	{
		for (j = 0; j < largeur; j++)
		{
			if (Map[i][j] == 'o')

				compteur++;
		}
	}
	return compteur;
}

// Cette fonction permet de passer au niveau suivant


char ** niveau_Suivant(int n, int * longueur, int * largeur)
{	
	char ** map = NULL;
	
	if (n == 1)		
	{
		map = charge_Map("Niveau-01.txt");	
		recupe_Dim_Map(longueur, largeur, "Niveau-01.txt");
	}
	else if (n == 2)
	{
		map = charge_Map("Niveau-02.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-02.txt");
	}

	else if (n == 3)
	{
		map = charge_Map("Niveau-03.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-03.txt");
	}
	else if (n == 4)
	{
		map = charge_Map("Niveau-04.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-04.txt");
	}
	else if (n == 5)
	{
		map = charge_Map("Niveau-05.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-05.txt");
	}
	else if (n == 6)
	{
		map = charge_Map("Niveau-06.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-06.txt");
	}
	else if (n == 7)
	{
		map = charge_Map("Niveau-07.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-07.txt");
	}
	else if (n == 8)
	{
		map = charge_Map("Niveau-08.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-08.txt");
	}	
	else if (n == 9)
	{
		map = charge_Map("Niveau-09.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-09.txt");
	}
	else if (n == 10)
	{
		map = charge_Map("Niveau-10.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-10.txt");
	}
	else if (n == 11)
	{
		map = charge_Map("Niveau-11.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-11.txt");
	}
	else if (n == 12)
	{
		map = charge_Map("Niveau-12.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-12.txt");
	}
	else if (n == 13)
	{
		map = charge_Map("Niveau-13.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-13.txt");
	}
	else if (n == 14)
	{
		map = charge_Map("Niveau-14.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-14.txt");
	}
	else if (n == 15)
	{
		map = charge_Map("Niveau-15.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-15.txt");
	}
	else if (n == 16)
	{
		map = charge_Map("Niveau-16.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-16.txt");
	}
	else if (n == 17)
	{
		map = charge_Map("Niveau-17.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-17.txt");
	}
	else if (n == 18)
	{
		map = charge_Map("Niveau-18.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-18.txt");
	}
	else if (n == 19)
	{
		map = charge_Map("Niveau-19.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-19.txt");
	}
	else if (n == 20)
	{
		map = charge_Map("Niveau-20.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-20.txt");
	}
	else if (n == 21)
	{
		map = charge_Map("Niveau-21.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-21.txt");
	}
	else if (n == 22)
	{
		map = charge_Map("Niveau-22.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-22.txt");
	}
	else if (n == 23)
	{
		map = charge_Map("Niveau-23.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-23.txt");
	}
	else if (n == 24)
	{
		map = charge_Map("Niveau-34.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-24.txt");
	}
	else if (n == 25)
	{
		map = charge_Map("Niveau-25.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-25.txt");
	}
	else if (n == 26)
	{
		map = charge_Map("Niveau-26.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-26.txt");
	}
	else if (n == 27)
	{
		map = charge_Map("Niveau-27.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-27.txt");
	}
	else if (n == 28)
	{
		map = charge_Map("Niveau-28.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-28.txt");
	}
	else if (n == 29)
	{
		map = charge_Map("Niveau-29.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-29.txt");
	}
	else if (n == 30)
	{
		map = charge_Map("Niveau-30.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-30.txt");
	}
	else if (n == 31) 
	{
		map = charge_Map("Niveau-31.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-31.txt");
	}
	else if (n == 32)
	{
		map = charge_Map("Niveau-32.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-32.txt");
	}
	else if (n == 33)
	{	
		map = charge_Map("Niveau-33.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-33.txt");
	}
	else if (n == 34)
	{
		map = charge_Map("Niveau-34.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-34.txt");
	}
	else if (n == 35)
	{
		map = charge_Map("Niveau-35.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-35.txt");
	}
	else if (n == 36)
	{
		map = charge_Map("Niveau-36.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-36.txt");
	}
	else if (n == 37)
	{
		map = charge_Map("Niveau-37.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-37.txt");
	}
	else if (n == 38)
	{
		map = charge_Map("Niveau-38.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-38.txt");
	}
	else if (n == 39)
	{
		map = charge_Map("Niveau-39.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-39.txt");
	}
	else if (n == 40)
	{
		map = charge_Map("Niveau-40.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-40.txt");
	}
	else if (n == 41)
	{
		map = charge_Map("Niveau-41.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-41.txt");
	}
	else if (n == 42)
	{
		map = charge_Map("Niveau-42.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-42.txt");
	}
	else if (n == 43)
	{
		map = charge_Map("Niveau-43.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-43.txt");
	}
	else if (n == 44)
	{
		map = charge_Map("Niveau-44.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-44.txt");
	}
	else if (n == 45)
	{	
		map = charge_Map("Niveau-45.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-45.txt");
	}
	if (n == 46)		
	{
		map = charge_Map("Niveau-46.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-46.txt");
	}
	else if (n == 47)
	{
		map = charge_Map("Niveau-47.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-47.txt");
	}
	else if (n == 48)
	{
		map = charge_Map("Niveau-48.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-48.txt");
	}
	else if (n == 49)
	{
		map = charge_Map("Niveau-49.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-49.txt");
	}
	else if (n == 50)
	{
		map = charge_Map("Niveau-50.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-50.txt");
	}
	else if (n == 51)
	{
		map = charge_Map("Niveau-51.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-51.txt");
	}
	else if (n == 52)
	{
		map = charge_Map("Niveau-52.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-52.txt");
	}
	else if (n == 53)
	{
		map = charge_Map("Niveau-53.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-53.txt");
	}
	else if (n == 54)
	{
		map = charge_Map("Niveau-54.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-54.txt");
	}
	else if (n == 55)
	{
		map = charge_Map("Niveau-55.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-55.txt");
	}
	else if (n == 56)
	{
		map = charge_Map("Niveau-56.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-56.txt");
	}
	else if (n == 57)
	{
		map = charge_Map("Niveau-57.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-57.txt");
	}
	else if (n == 58)
	{
		map = charge_Map("Niveau-58.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-58.txt");
	}
	else if (n == 59)
	{
		map = charge_Map("Niveau-59.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-03.txt");
	}
	else if (n == 60)
	{
		map = charge_Map("Niveau-60.txt");
		recupe_Dim_Map(longueur, largeur, "Niveau-60.txt");
	}

	return map;
}
